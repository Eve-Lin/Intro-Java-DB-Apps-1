create
  definer = root@localhost procedure udp_find_playmaker(IN min_dribble_points int, IN team_name varchar(45))
BEGIN
select concat(p.first_name, ' ', p.last_name) as `full_name`, p.age, p.salary, sd.dribbling, sd.speed, ts.`name` from players p
join skills_data sd on
sd.id = p.skills_data_id join
teams ts on
ts.id = p.team_id
where sd.dribbling > min_dribble_points and 
ts.`name` like team_name and sd.speed > (
select avg(sd.speed) from skills_data sd
)
order by sd.speed desc
limit 1;
END;

